from django.shortcuts import render

def index(request):
    return render(request, 'index.html')
def we(request):
    return render(request, 'index.html')
