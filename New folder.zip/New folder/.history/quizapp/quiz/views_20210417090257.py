from django.shortcuts import render
from .models import Questions
from django.core.paginator import Paginator

def index(request):
    obj = Questions.objects.all()
    return render(request, 'index.html', {'obj':obj})
def welcome(request):
    return render(request, 'welcome.html')
