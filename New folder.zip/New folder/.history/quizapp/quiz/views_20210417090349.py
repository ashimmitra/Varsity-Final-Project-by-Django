from django.shortcuts import render
from .models import Questions
from django.core.paginator import Paginator

def index(request):
    obj = Questions.objects.all()
    paginator = Paginator(obj,1)
        try:
            page = int(request.GET.get('page','1'))  
        except:
            page =1
        try:
                questions = paginator.page(page)
            except(EmptyPage,InvalidPage):
        
                questions=paginator.page(paginator.num_pages)
    return render(request, 'index.html', {'obj':obj})
def welcome(request):
    return render(request, 'welcome.html')
