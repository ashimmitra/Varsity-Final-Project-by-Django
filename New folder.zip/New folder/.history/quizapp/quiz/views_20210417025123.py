from django.shortcuts import render
from .models import Questions

def index(request):
    obj = Ob
    return render(request, 'index.html')
def welcome(request):
    return render(request, 'welcome.html')
