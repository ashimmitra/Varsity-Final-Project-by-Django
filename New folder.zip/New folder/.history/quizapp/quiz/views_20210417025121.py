from django.shortcuts import render
from .models import Questions

def index(request):
    obj = O
    return render(request, 'index.html')
def welcome(request):
    return render(request, 'welcome.html')
