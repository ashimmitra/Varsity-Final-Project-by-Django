window.onload = initall;
var saveAnsButton;

function initall() {
    saveAnsButton = document.getElementById('saveans')
    saveAnsButton.onclick = saveans;
}

function saveans() {
    var ans = $("input:radio[name=name]:checked").val()
    alert("answer submited go next")
    var url = '/saveans?ans=' + ans
    var req = new XMLHttpRequest();

    req.open("GET", url, true);
    req.send();
}