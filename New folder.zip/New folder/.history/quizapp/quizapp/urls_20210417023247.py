
from django.contrib import admin
from django.urls import path
from im

urlpatterns = [
    path('admin/', admin.site.urls),
    path('',views.index),
]
