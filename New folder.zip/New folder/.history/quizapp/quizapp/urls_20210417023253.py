
from django.contrib import admin
from django.urls import path
from  quiz imp

urlpatterns = [
    path('admin/', admin.site.urls),
    path('',views.index),
]
